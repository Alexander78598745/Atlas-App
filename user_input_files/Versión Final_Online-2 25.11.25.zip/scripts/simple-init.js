// VERSIÓN SIMPLIFICADA Y ROBUSTA
// Crear una versión nueva que garantice funcionamiento

// Función principal de inicialización simplificada
function initAppSimple() {
    console.log('🚀 Inicializando aplicación simplificada...');
    
    // Configurar event listeners de forma explícita
    setupSimpleEventListeners();
    
    // Configurar navegación
    setupSimpleNavigation();
    
    // Mostrar dashboard por defecto
    showPage('dashboard');
    
    console.log('✅ Aplicación inicializada correctamente');
}

// Event listeners simplificados
function setupSimpleEventListeners() {
    console.log('📋 Configurando event listeners...');
    
    // Botón Nuevo Viaje
    const newTripBtn = document.getElementById('newTripBtn');
    if (newTripBtn) {
        // Remover cualquier onclick existente
        newTripBtn.removeAttribute('onclick');
        // Agregar event listener explícito
        newTripBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('🆕 Nuevo Viaje clicked');
            createNewTrip();
        });
        console.log('✅ Event listener para Nuevo Viaje configurado');
    } else {
        console.log('❌ newTripBtn no encontrado');
    }
    
    // Botón menú usuario
    const userMenuBtn = document.getElementById('userMenuBtn');
    if (userMenuBtn) {
        userMenuBtn.removeAttribute('data-action');
        userMenuBtn.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('👤 Menu usuario clicked');
            toggleUserMenu();
        });
        console.log('✅ Event listener para menú usuario configurado');
    } else {
        console.log('❌ userMenuBtn no encontrado');
    }
    
    // Link editar perfil
    const editProfileLink = document.querySelector('[data-action="edit-profile"]');
    if (editProfileLink) {
        editProfileLink.removeAttribute('data-action');
        editProfileLink.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('✏️ Editar perfil clicked');
            handleUserMenuAction('edit-profile');
        });
        console.log('✅ Event listener para editar perfil configurado');
    }
    
    // Navegación de páginas
    const pageLinks = document.querySelectorAll('[data-page]');
    pageLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.getAttribute('data-page');
            console.log('📄 Navegando a:', page);
            showPage(page);
        });
    });
    console.log(`✅ Event listeners de navegación configurados (${pageLinks.length} enlaces)`);
}

// Función para mostrar páginas simplificada
function showPage(pageName) {
    console.log('📱 Mostrando página:', pageName);
    
    // Ocultar todas las páginas
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => {
        page.classList.add('hidden');
    });
    
    // Mostrar página solicitada
    const targetPage = document.getElementById(`${pageName}Page`);
    if (targetPage) {
        targetPage.classList.remove('hidden');
        
        // Actualizar navegación activa
        const navLinks = document.querySelectorAll('[data-page]');
        navLinks.forEach(link => {
            link.classList.remove('bg-primary-100', 'text-primary-700');
            link.classList.add('text-neutral-600');
            
            if (link.getAttribute('data-page') === pageName) {
                link.classList.remove('text-neutral-600');
                link.classList.add('bg-primary-100', 'text-primary-700');
            }
        });
        
        console.log(`✅ Página ${pageName} mostrada correctamente`);
    } else {
        console.log(`❌ Página ${pageName} no encontrada`);
    }
}

// Función para probar funcionalidades
function testAllFunctions() {
    console.log('\n🧪 TESTING TODAS LAS FUNCIONES:');
    
    const functions = {
        'createNewTrip': 'Crear nuevo viaje',
        'toggleUserMenu': 'Alternar menú usuario',
        'handleUserMenuAction': 'Acción menú usuario',
        'addDiaryEntry': 'Agregar entrada diario',
        'showRouteDetails': 'Mostrar detalles ruta'
    };
    
    Object.entries(functions).forEach(([funcName, description]) => {
        if (typeof window[funcName] === 'function') {
            console.log(`✅ ${funcName}() - ${description}: EXISTE`);
        } else {
            console.log(`❌ ${funcName}() - ${description}: NO EXISTE`);
        }
    });
}

// Función para debugging
function debugElements() {
    console.log('\n🔍 DEBUGGING ELEMENTOS DOM:');
    
    const elements = {
        'newTripBtn': 'Botón Nuevo Viaje',
        'userMenuBtn': 'Botón Menú Usuario',
        'userMenuDropdown': 'Dropdown Menú Usuario'
    };
    
    Object.entries(elements).forEach(([id, description]) => {
        const element = document.getElementById(id);
        if (element) {
            console.log(`✅ ${description} (${id}): ENCONTRADO`);
            console.log(`   - Visible: ${element.offsetWidth > 0 ? 'SÍ' : 'NO'}`);
            console.log(`   - Classes: ${element.className}`);
        } else {
            console.log(`❌ ${description} (${id}): NO ENCONTRADO`);
        }
    });
}

// Ejecutar inicialización cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 DOM cargado, inicializando...');
    
    // Pequeño delay para asegurar que todos los elementos están disponibles
    setTimeout(() => {
        initAppSimple();
        testAllFunctions();
        debugElements();
    }, 100);
});

// Exportar funciones para uso manual en consola
window.testAllFunctions = testAllFunctions;
window.debugElements = debugElements;
window.showPage = showPage;
window.initAppSimple = initAppSimple;

console.log('🚀 Script de inicialización simplificada cargado');